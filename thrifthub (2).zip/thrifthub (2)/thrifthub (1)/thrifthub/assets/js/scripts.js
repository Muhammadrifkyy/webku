// Fungsi JS tambahan jika diperlukan
console.log("ThriftHub JS aktif!");
