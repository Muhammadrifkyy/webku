<?php
session_start();
include '../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user_id = $_POST['user_id'];
  $action = $_POST['action'];

  if ($action === 'approve') {
    $stmt = $conn->prepare("UPDATE users SET is_seller = 1, request_seller = 0 WHERE id = ?");
  } else {
    $stmt = $conn->prepare("UPDATE users SET request_seller = 0 WHERE id = ?");
  }

  $stmt->bind_param("i", $user_id);
  $stmt->execute();
}

header("Location: ../views/admin/admin_verifikasi_toko.php");
exit;
