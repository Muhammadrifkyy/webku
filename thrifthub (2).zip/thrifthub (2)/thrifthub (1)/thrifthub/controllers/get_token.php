<?php
require_once __DIR__ . '/../libraries/midtrans/Midtrans.php';

// Konfigurasi Midtrans
\Midtrans\Config::$serverKey = 'Mid-server-ghMn6hd0NNLQubv9nfU-mlzF'; // ✅ Server key asli
\Midtrans\Config::$isProduction = false;
\Midtrans\Config::$isSanitized = true;
\Midtrans\Config::$is3ds = true;

// Ambil data dari POST JSON (fetch)
$data = json_decode(file_get_contents('php://input'), true);

// Validasi input
if (!$data || !isset($data['total'], $data['cart'], $data['nama'], $data['alamat'], $data['order_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Data tidak lengkap.']);
    exit;
}

// Ambil variabel
$order_id = $data['order_id'];
$gross_amount = $data['total'];
$nama = $data['nama'];
$alamat = $data['alamat'];
$cart = $data['cart'];

// Format item_details dari keranjang
$item_details = [];
foreach ($cart as $index => $item) {
    $item_details[] = [
        'id' => 'item-' . $index,
        'price' => $item['price'],
        'quantity' => $item['quantity'],
        'name' => $item['name']
    ];
}

// Data transaksi Midtrans
$transaction = [
    'transaction_details' => [
        'order_id' => $order_id,
        'gross_amount' => $gross_amount,
    ],
    'item_details' => $item_details,
    'customer_details' => [
        'first_name' => $nama,
        'email' => 'user@example.com', // Ganti kalau kamu punya dari session
        'billing_address' => [
            'address' => $alamat
        ],
        'shipping_address' => [
            'address' => $alamat
        ]
    ]
];

// Ambil token Snap
try {
    $snapToken = \Midtrans\Snap::getSnapToken($transaction);
    echo json_encode(['token' => $snapToken]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Gagal membuat token: ' . $e->getMessage()]);
}
