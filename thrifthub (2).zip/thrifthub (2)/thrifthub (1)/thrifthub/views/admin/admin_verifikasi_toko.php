<?php
if (session_status() === PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
  header("Location: index.php?url=login");
  exit;
}

$title = "Verifikasi Toko - Admin";
include 'middlewares/admin_only.php';
include __DIR__ . '/../../config/database.php';
ob_start();

// Ambil user yang belum diverifikasi sebagai seller
$sql = "SELECT id, name, email, created_at FROM users WHERE is_seller = 0 AND request_seller = 1 ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<div class="container py-5">
  <h2 class="fw-bold mb-4 text-center text-dark">
    <i class="bi bi-patch-check-fill me-2"></i> Permintaan Verifikasi Toko
  </h2>

  <?php if ($result->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered text-center align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Tanggal Permintaan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no=1; while($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= date('d M Y H:i', strtotime($row['created_at'])) ?></td>
            <td>
              <form action="controllers/admin_verifikasi_toko_proses.php" method="POST" class="d-inline">
                <input type="hidden" name="user_id" value="<?= $row['id'] ?>">
                <button name="action" value="approve" class="btn btn-sm btn-success rounded-pill">Setujui</button>
                <button name="action" value="reject" class="btn btn-sm btn-outline-danger rounded-pill">Tolak</button>
              </form>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="alert alert-info text-center">Tidak ada permintaan verifikasi toko saat ini.</div>
  <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/admin_layout.php';
?>
