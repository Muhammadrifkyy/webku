<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'user') {
    header("Location: index.php?url=login");
    exit;
}

$title = "Riwayat Penjualan - ThriftHub";
ob_start();

include_once 'config/database.php';
$user_id = $_SESSION['user']['id'];

// Ambil produk yang dimiliki user, lalu tampilkan jika produk itu sudah dibeli orang lain
$query = "
SELECT 
  p.nama AS nama_produk,
  p.harga,
  pi.jumlah,
  ps.nama AS nama_pembeli,
  ps.alamat,
  ps.tanggal,
  ps.status_pengiriman,
  ps.status_pembayaran
FROM pesanan_item pi
JOIN produk p ON pi.produk_id = p.id
JOIN pesanan ps ON pi.pesanan_id = ps.id
WHERE p.user_id = ?
ORDER BY ps.tanggal DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container py-5">
  <h3 class="fw-bold text-center mb-4" style="color:#85005A">
    <i class="bi bi-cash-coin me-2"></i>Riwayat Penjualan
  </h3>

  <?php if ($result->num_rows > 0): ?>
    <div class="table-responsive">
      <table class="table table-bordered table-hover text-center align-middle">
        <thead class="table-light">
          <tr>
            <th>No</th>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Harga Satuan</th>
            <th>Total</th>
            <th>Pembeli</th>
            <th>Tanggal</th>
            <th>Status Bayar</th>
            <th>Status Kirim</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= htmlspecialchars($row['nama_produk']); ?></td>
              <td><?= $row['jumlah']; ?></td>
              <td>Rp<?= number_format($row['harga'], 0, ',', '.'); ?></td>
              <td class="fw-bold text-danger">Rp<?= number_format($row['harga'] * $row['jumlah'], 0, ',', '.'); ?></td>
              <td><?= htmlspecialchars($row['nama_pembeli']); ?></td>
              <td><?= date('d M Y - H:i', strtotime($row['tanggal'])); ?></td>
              <td><span class="badge bg-<?= $row['status_pembayaran'] === 'Pembayaran Diterima' ? 'success' : 'warning' ?>">
                <?= $row['status_pembayaran']; ?>
              </span></td>
              <td><span class="badge bg-<?= $row['status_pengiriman'] === 'Dikirim' ? 'success' : 'secondary' ?>">
                <?= $row['status_pengiriman']; ?>
              </span></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="text-center py-5">
      <i class="bi bi-emoji-frown display-4 text-muted"></i>
      <h5 class="mt-3 text-secondary">Belum ada produk yang berhasil kamu jual.</h5>
      <a href="index.php?url=my_products" class="btn btn-outline-primary mt-3 px-4 rounded-pill">
        <i class="bi bi-plus-circle me-1"></i> Tambah Produk
      </a>
    </div>
  <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/admin_store_dashboard.php';
?>
