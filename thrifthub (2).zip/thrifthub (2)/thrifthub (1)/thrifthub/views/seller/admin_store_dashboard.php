<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config/database.php';

// Cek akses: hanya admin_toko
if (!isset($_SESSION['user']) || $_SESSION['user']['is_seller'] != 1) {
    echo "Akses ditolak.";
    exit;
}

$title = "Dashboard Toko";
ob_start();

// Data statistik toko
$seller_id = $_SESSION['user']['id'];

$totalProduk = $conn->query("SELECT COUNT(*) AS jumlah FROM produk WHERE user_id = $seller_id")->fetch_assoc()['jumlah'] ?? 0;
$totalTerjual = $conn->query("SELECT SUM(pi.jumlah) AS terjual 
  FROM pesanan_item pi
  JOIN pesanan p ON pi.pesanan_id = p.id
  JOIN produk pr ON pi.produk_id = pr.id
  WHERE pr.user_id = $seller_id")->fetch_assoc()['terjual'] ?? 0;
$pendapatan = $conn->query("SELECT SUM(pi.harga * pi.jumlah) AS total 
  FROM pesanan_item pi
  JOIN pesanan p ON pi.pesanan_id = p.id
  JOIN produk pr ON pi.produk_id = pr.id
  WHERE pr.user_id = $seller_id")->fetch_assoc()['total'] ?? 0;
?>

<div class="container py-5">
 <h2 class="mb-4 fw-bold text-center" style="color: #85005A;">Dashboard Toko Anda</h2>
  <div class="row text-center g-4">
    <div class="col-md-4">
      <div class="card shadow-sm border-0">
        <div class="card-body">
          <i class="bi bi-box-seam fs-1 text-primary"></i>
          <h5 class="mt-2">Produk Aktif</h5>
          <p class="fs-4"><?= $totalProduk ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm border-0">
        <div class="card-body">
          <i class="bi bi-cart-check fs-1 text-success"></i>
          <h5 class="mt-2">Total Terjual</h5>
          <p class="fs-4"><?= $totalTerjual ?: 0 ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm border-0">
        <div class="card-body">
          <i class="bi bi-cash-stack fs-1 text-warning"></i>
          <h5 class="mt-2">Pendapatan</h5>
          <p class="fs-4">Rp <?= number_format($pendapatan ?: 0, 0, ',', '.') ?></p>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/admin_store_dashboard.php';
?>