# ThriftHub - Platform Jual Beli Baju Preloved (C2C)

## Deskripsi
Aplikasi web sederhana berbasis PHP Native untuk mempertemukan penjual dan pembeli baju bekas berkualitas.

## Fitur
- Register & Login
- Peran Pengguna (Admin & User)
- Upload Produk (nama, deskripsi, harga, foto)
- Dashboard Penjual
- Panel Admin
- Sistem Pembayaran: COD / Transfer
- Sistem Pengiriman: Ambil sendiri / Kurir

## Teknologi
- PHP Native
- MySQL
- Bootstrap 5
- JavaScript
- Font Awesome

## Struktur Folder
