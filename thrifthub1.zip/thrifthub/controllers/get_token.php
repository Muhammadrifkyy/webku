<?php
require_once __DIR__ . '/../libraries/midtrans/Midtrans.php';
include __DIR__ . '/../config/database.php'; // ⬅️ Pastikan koneksi DB dimuat

// Midtrans config
\Midtrans\Config::$serverKey = 'Mid-server-ghMn6hd0NNLQubv9nfU-mlzF';
\Midtrans\Config::$isProduction = false;
\Midtrans\Config::$isSanitized = true;
\Midtrans\Config::$is3ds = true;

// Ambil data dari JSON
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['total'], $data['cart'], $data['nama'], $data['alamat'], $data['order_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Data tidak lengkap.']);
    exit;
}

$order_id = $data['order_id'];
$gross_amount = $data['total'];
$nama = $data['nama'];
$alamat = $data['alamat'];
$cart = $data['cart'];
$metode = 'Transfer';
$tanggal = date("Y-m-d H:i:s");
$user_id = $_SESSION['user']['id'] ?? null;

// ✅ Cek dulu apakah pesanan dengan order_id ini sudah ada
$cek = $conn->prepare("SELECT id FROM pesanan WHERE order_id = ?");
$cek->bind_param("s", $order_id);
$cek->execute();
$cek->store_result();

if ($cek->num_rows === 0 && $user_id) {
    // 🔽 Simpan pesanan dulu sebelum snap
    $status_pembayaran = 'Pending';
    $status_pengiriman = 'Belum Diproses';

    $stmt = $conn->prepare("INSERT INTO pesanan 
        (user_id, nama, alamat, metode, tanggal, total, order_id, status_pembayaran, status_pengiriman)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssdsss", $user_id, $nama, $alamat, $metode, $tanggal, $gross_amount, $order_id, $status_pembayaran, $status_pengiriman);
    $stmt->execute();
    $pesanan_id = $stmt->insert_id;

    // 🔽 Simpan detail item
    $stmtItem = $conn->prepare("INSERT INTO pesanan_item (pesanan_id, produk_id, nama, harga, jumlah) VALUES (?, ?, ?, ?, ?)");
    foreach ($cart as $item) {
        $stmtItem->bind_param("iisdi", $pesanan_id, $item['id'], $item['name'], $item['price'], $item['quantity']);
        $stmtItem->execute();
    }
}

// Lanjut buat Snap Token
$item_details = [];
foreach ($cart as $index => $item) {
    $item_details[] = [
        'id' => 'item-' . $index,
        'price' => $item['price'],
        'quantity' => $item['quantity'],
        'name' => $item['name']
    ];
}

$transaction = [
    'transaction_details' => [
        'order_id' => $order_id,
        'gross_amount' => $gross_amount,
    ],
    'item_details' => $item_details,
    'customer_details' => [
        'first_name' => $nama,
        'email' => 'user@example.com',
        'billing_address' => ['address' => $alamat],
        'shipping_address' => ['address' => $alamat]
    ]
];

try {
    $snapToken = \Midtrans\Snap::getSnapToken($transaction);
    echo json_encode(['token' => $snapToken]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Gagal membuat token: ' . $e->getMessage()]);
}
